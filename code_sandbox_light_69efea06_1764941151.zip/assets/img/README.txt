This folder contains project images.
Icons are implemented via FontAwesome in the prototype.
