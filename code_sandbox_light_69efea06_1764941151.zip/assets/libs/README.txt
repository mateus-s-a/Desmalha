This folder is intended for local library files (Bootstrap, Math.js).
In this static deployment, we are using CDN links in the HTML files for performance.
